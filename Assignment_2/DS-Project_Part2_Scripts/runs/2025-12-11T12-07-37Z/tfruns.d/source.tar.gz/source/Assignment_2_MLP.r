# ==============================================================================
# 0. Environment Setup (M3 Apple Silicon)
# ==============================================================================
library(reticulate)
library(tensorflow)
library(keras3)
library(caret)
library(dplyr)
library(tfruns)

# Force the specific M3 environment we fixed earlier
# (This prevents R from wandering off to other Python versions)
use_python("/Users/Jujou/miniforge3/envs/tf_m3_env/bin/python", required = TRUE)

# Helper function for "Default value if null" (replaces %||%)
`%||%` <- function(x, y) if (is.null(x)) y else x

# ==============================================================================
# 1. Hyperparameter flags
# ==============================================================================
FLAGS <- flags(
  # Regularization
  flag_numeric("dropout1", 0),
  flag_numeric("dropout2", 0),
  flag_numeric("dropout3", 0.0), # For optional 3rd layer
  
  # Architecture
  flag_integer("units1", 128),
  flag_integer("units2", 256),
  flag_integer("units3", 0),     # 0 = off (2 layers), >0 = on (3 layers)
  
  # Optimization
  flag_numeric("learning_rate", 0.001),
  flag_integer("batch_size", 128),
  flag_integer("epochs", 100)
)

# ==============================================================================
# 2. Load & Prepare Data
# ==============================================================================
data <- read.csv(
  "/Users/Jujou/Documents/Repos/GRP-6_DS-Project/DS-Project_data/Intermediate/Assignment_2_cleaned.csv"
)
target_col <- "target_class"

# Feature Matrix
x_all <- data %>%
  select(-all_of(target_col)) %>%
  as.matrix()

# --- FIX: Target Variable Setup for Python/TensorFlow ---
# 1. Convert to strict Integer (Python rejects decimals/floats for classes)
# 2. Subtract 1 (R is 1-based [1..8], Python is 0-based [0..7])
raw_labels <- as.integer(data[[target_col]]) - 1

# 3. Use tf$keras directly to avoid library mismatches
y_all <- tf$keras$utils$to_categorical(raw_labels, num_classes = 8L)

# ==============================================================================
# 3. Split Data
# ==============================================================================
set.seed(42)

# Holdout Test Set (15%)
n_rows  <- nrow(x_all)
test_idx <- sample(1:n_rows, size = floor(0.15 * n_rows))

x_test_holdout_raw <- x_all[test_idx, ]
y_test_holdout     <- y_all[test_idx, ]

x_cv_raw <- x_all[-test_idx, ]
y_cv     <- y_all[-test_idx, ]

# ==============================================================================
# 4. Cross-Validation Setup
# ==============================================================================
k <- 5
folds <- cut(seq(1, nrow(x_cv_raw)), breaks = k, labels = FALSE)

# Initialize Storage
results <- data.frame(
  Fold       = integer(k),
  Train_Loss = numeric(k),
  Val_Loss   = numeric(k),
  Train_Acc  = numeric(k),
  Val_Acc    = numeric(k)
)

cat("Starting", k, "-Fold Cross-Validation (Variable Depth)...\n")

# ==============================================================================
# 5. Training Loop
# ==============================================================================
for (i in seq_len(k)) {
  cat("\n--- Processing Fold #", i, "---\n")
  
  # a. Split
  val_indices      <- which(folds == i, arr.ind = TRUE)
  x_fold_val_raw   <- x_cv_raw[val_indices, , drop = FALSE]
  y_fold_val       <- y_cv[val_indices, , drop = FALSE]
  x_fold_train_raw <- x_cv_raw[-val_indices, , drop = FALSE]
  y_fold_train     <- y_cv[-val_indices, , drop = FALSE]
  
  # b. Robust Scaling (Include 'zv' for safety)
  fold_scaler <- preProcess(x_fold_train_raw, method = c("zv", "center", "scale"))
  x_fold_train <- predict(fold_scaler, x_fold_train_raw)
  x_fold_val   <- predict(fold_scaler, x_fold_val_raw)
  
  # c. Define Model (Variable Depth Logic)
  # Base: Input + Layer 1 + Layer 2
  model <- keras_model_sequential() %>%
    layer_input(input_shape = c(ncol(x_fold_train))) %>%
    layer_dense(units = FLAGS$units1, activation = "relu") %>%
    layer_dropout(rate = FLAGS$dropout1) %>%
    layer_dense(units = FLAGS$units2, activation = "relu") %>%
    layer_dropout(rate = FLAGS$dropout2)
  
  # Optional: Layer 3 (only if units3 > 0)
  if (FLAGS$units3 > 0) {
    model <- model %>%
      layer_dense(units = FLAGS$units3, activation = "relu") %>%
      layer_dropout(rate = FLAGS$dropout3)
  }
  
  # Output Layer
  model <- model %>%
    layer_dense(units = 8, activation = "softmax")
  
  # d. Compile
  model %>% compile(
    loss      = "categorical_crossentropy",
    optimizer = optimizer_adam(learning_rate = FLAGS$learning_rate),
    metrics   = c("accuracy")
  )
  
  # e. Train (Clean Output)
  history <- model %>% fit(
    x = x_fold_train,
    y = y_fold_train,
    batch_size = FLAGS$batch_size,
    epochs     = FLAGS$epochs,
    verbose    = 0,
    validation_data = list(x_fold_val, y_fold_val)
  )
  
  # f. Extract BEST Metrics
  # Use %||% helper to check both naming conventions
  metrics <- history$metrics
  
  val_acc_vec   <- metrics$val_accuracy %||% metrics$val_acc
  train_acc_vec <- metrics$accuracy     %||% metrics$acc
  val_loss_vec  <- metrics$val_loss
  train_loss_vec <- metrics$loss
  
  best_epoch_idx <- which.max(val_acc_vec)
  best_val_acc   <- val_acc_vec[best_epoch_idx]
  best_train_acc <- train_acc_vec[best_epoch_idx]
  final_val_loss <- val_loss_vec[best_epoch_idx]
  final_train_loss <- train_loss_vec[best_epoch_idx]
  
  # Store
  results[i, ] <- c(i, final_train_loss, final_val_loss, best_train_acc, best_val_acc)
  
  cat(sprintf("Fold %d | Max Val Acc: %.4f (at Epoch %d)\n",
              i, best_val_acc, best_epoch_idx))
  
  # Explicit cleanup to free GPU memory between folds
  k_clear_session() 
}

# ==============================================================================
# 6. Final Report
# ==============================================================================
cat("\n========================================\n")
cat("      ARCHITECTURE PERFORMANCE          \n")
cat("========================================\n")

avg_train_acc <- mean(results$Train_Acc)
avg_val_acc   <- mean(results$Val_Acc)
gap           <- avg_train_acc - avg_val_acc

cat("Avg Train Accuracy: ", round(avg_train_acc, 4), "\n")
cat("Avg Val Accuracy:   ", round(avg_val_acc, 4), "\n")
cat("Overfitting Gap:    ", round(gap, 4), "\n")
cat("----------------------------------------\n")

if (gap > 0.05) {
  cat("WARNING: High Overfitting. Increase Dropout.\n")
} else if (avg_train_acc < 0.70) {
  cat("WARNING: Underfitting. Increase Units/Layers.\n")
} else {
  cat("STATUS: Good candidate architecture.\n")
}

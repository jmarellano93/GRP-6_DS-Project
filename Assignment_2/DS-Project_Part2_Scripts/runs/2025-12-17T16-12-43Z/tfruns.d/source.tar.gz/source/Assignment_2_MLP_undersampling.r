# ==============================================================================
# UPDATES FOR IMBALANCED DATA (UNDERSAMPLING VERSION, NO K-FOLD):
# 1. Split: Stratified Train (70%) / Validation (15%) / Test (15%)
# 2. Undersample class 0 in TRAINING ONLY
# 3. Metrics: Macro F1 and Balanced Accuracy on the Validation Set
# ==============================================================================

library(keras3)
library(caret)
library(dplyr)
library(tfruns)
library(tensorflow)

# 1. Hyperparameter flags ------------------------------------------------
FLAGS <- flags(
  # Regularization
  flag_numeric("dropout1", 0),
  flag_numeric("dropout2", 0),
  flag_numeric("dropout3", 0.0), 
  
  # Architecture
  flag_integer("units1", 512),
  flag_integer("units2", 256),
  flag_integer("units3", 128),     
  
  # Optimization
  flag_numeric("learning_rate", 0.0001),
  flag_integer("batch_size", 256),
  flag_integer("epochs", 5000)
)

# 2. Load & Prepare Data -------------------------------------------------
data <- read.csv(
  "/Users/Jujou/Documents/Repos/GRP-6_DS-Project/DS-Project_data/Intermediate/Assignment_2_cleaned_v3.csv"
)

target_col <- "target_class"

x_all <- data %>% select(-all_of(target_col)) %>% as.matrix()
y_raw <- data[[target_col]]
y_all <- to_categorical(y_raw, num_classes = 7)
y_factor <- factor(y_raw)

# 3. Stratified Split: Train / Val / Test --------------------------------
set.seed(42)

# --- Test (15%) ---
test_idx <- createDataPartition(y_factor, p = 0.15, list = FALSE)

x_test_raw <- x_all[test_idx, ]
y_test     <- y_all[test_idx, ]

x_remain <- x_all[-test_idx, ]
y_remain <- y_all[-test_idx, ]
y_remain_raw <- y_raw[-test_idx]
y_remain_factor <- factor(y_remain_raw)

# --- Validation (15% total) ---
val_p <- 0.15 / 0.85
val_idx <- createDataPartition(y_remain_factor, p = val_p, list = FALSE)

x_val_raw <- x_remain[val_idx, ]
y_val     <- y_remain[val_idx, ]

# --- Training (~70%) ---
x_train_raw <- x_remain[-val_idx, ]
y_train_raw <- y_remain_raw[-val_idx]
y_train     <- y_all[-test_idx, ][-val_idx, ]

cat("Before undersampling:\n")
print(table(y_train_raw))

# 4. UNDERSAMPLING CLASS 0 (TRAIN ONLY) ----------------------------------
set.seed(42)

train_df <- data.frame(x_train_raw)
train_df$target <- y_train_raw

majority_class <- 0

# Target size: 2x largest minority class
class_counts <- table(train_df$target)
target_n0 <- 2 * max(class_counts[names(class_counts) != "0"])

df_majority <- train_df %>% filter(target == majority_class)
df_minority <- train_df %>% filter(target != majority_class)

df_majority_down <- df_majority %>%
  sample_n(size = min(target_n0, nrow(df_majority)))

train_balanced <- bind_rows(df_majority_down, df_minority) %>%
  sample_frac(1)

cat("\nAfter undersampling:\n")
print(table(train_balanced$target))

# Rebuild matrices
x_train_raw <- as.matrix(train_balanced %>% select(-target))
y_train     <- to_categorical(train_balanced$target, num_classes = 7)

# 5. Preprocessing (Robust Scaling) --------------------------------------
scaler <- preProcess(x_train_raw, method = c("zv", "center", "scale"))

x_train <- predict(scaler, x_train_raw)
x_val   <- predict(scaler, x_val_raw)

# 6. Define Model --------------------------------------------------------
model <- keras_model_sequential() %>%
  layer_dense(
    units = FLAGS$units1,
    activation = "relu",
    input_shape = c(ncol(x_train))
  ) %>%
  layer_dropout(rate = FLAGS$dropout1) %>%
  
  layer_dense(units = FLAGS$units2, activation = "relu") %>%
  layer_dropout(rate = FLAGS$dropout2)

if (FLAGS$units3 > 0) {
  model <- model %>%
    layer_dense(units = FLAGS$units3, activation = "relu") %>%
    layer_dropout(rate = FLAGS$dropout3)
}

model <- model %>%
  layer_dense(units = 7, activation = "softmax")

# 7. Compile -------------------------------------------------------------
model %>% compile(
  loss = "categorical_crossentropy",
  optimizer = tf$keras$optimizers$AdamW(
    learning_rate = FLAGS$learning_rate,
    weight_decay = 0.1
  ),
  metrics = "accuracy"
)

# 8. Diagnostics Callback ------------------------------------------------
callback_weightnorm_f1 <- callback_lambda(
  on_epoch_end = function(epoch, logs) {
    if (epoch %% 50 == 0) {
      
      weight_norm <- sum(sapply(
        model$trainable_weights,
        function(w) as.numeric(tf$norm(w))
      ))
      
      val_probs <- model %>% predict(x_val, verbose = 0)
      val_preds <- apply(val_probs, 1, which.max) - 1
      val_true  <- apply(y_val, 1, which.max) - 1
      
      cm <- confusionMatrix(
        factor(val_preds, levels = 0:6),
        factor(val_true, levels = 0:6),
        mode = "everything"
      )
      
      macro_f1 <- mean(cm$byClass[, "F1"], na.rm = TRUE)
      bal_acc  <- mean(cm$byClass[, "Balanced Accuracy"], na.rm = TRUE)
      
      cat("\n======================================================\n")
      message(sprintf("EPOCH %d DIAGNOSTICS:\n", epoch + 1))
      message(sprintf(" > Weight Norm:  %.2f\n", weight_norm))
      message(sprintf(" > Val Macro F1: %.4f\n", macro_f1))
      message(sprintf(" > Val Bal Acc:  %.4f\n", bal_acc))
      cat("======================================================\n")
      flush.console()
    }
  }
)

# 9. Train ---------------------------------------------------------------
history <- model %>% fit(
  x_train, y_train,
  epochs = FLAGS$epochs,
  batch_size = FLAGS$batch_size,
  validation_data = list(x_val, y_val),
  callbacks = list(callback_weightnorm_f1)
)

# 10. Final Metrics ------------------------------------------------------
best_epoch <- which.max(history$metrics$val_accuracy)

best_train_acc <- history$metrics$accuracy[best_epoch]
best_val_acc   <- history$metrics$val_accuracy[best_epoch]
final_val_loss <- history$metrics$val_loss[best_epoch]

val_probs <- model %>% predict(x_val, verbose = 0)
val_preds <- apply(val_probs, 1, which.max) - 1
val_true  <- apply(y_val, 1, which.max) - 1

cm <- confusionMatrix(
  factor(val_preds, levels = 0:6),
  factor(val_true, levels = 0:6),
  mode = "everything"
)

macro_f1 <- mean(cm$byClass[, "F1"], na.rm = TRUE)
bal_acc  <- mean(cm$byClass[, "Balanced Accuracy"], na.rm = TRUE)

# 11. Report -------------------------------------------------------------
cat("\n========================================\n")
cat("      SINGLE RUN PERFORMANCE          \n")
cat("========================================\n")

gap <- best_train_acc - best_val_acc

cat("Train Accuracy:     ", round(best_train_acc, 4), "\n")
cat("Val Accuracy:       ", round(best_val_acc, 4), "\n")
cat("Val Macro F1:       ", round(macro_f1, 4), "\n")
cat("Val Balanced Acc:   ", roun
    
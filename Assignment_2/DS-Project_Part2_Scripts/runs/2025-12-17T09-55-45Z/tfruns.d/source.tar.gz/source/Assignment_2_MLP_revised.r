library(keras3)
library(caret)
library(dplyr)
library(tfruns)
library(tensorflow)

# 1. Hyperparameter flags ------------------------------------------------
FLAGS <- flags(
  flag_integer("units1", 128),
  flag_integer("units2", 64),
  flag_integer("units3", 0),
  flag_numeric("dropout1", 0.0),
  flag_numeric("dropout2", 0.0),
  flag_numeric("dropout3", 0.0),
  flag_numeric("weight_decay", 0.01),
  flag_numeric("learning_rate", 0.001),
  flag_integer("batch_size", 64),
  flag_integer("epochs", 1000)
)

# 2. Load Data -----------------------------------------------------------
data <- read.csv("/Users/Jujou/Documents/Repos/GRP-6_DS-Project/DS-Project_data/Intermediate/Assignment_2_cleaned_v2.csv")
target_col <- "target_class"

x_all <- data %>% select(-all_of(target_col)) %>% as.matrix()
y_all <- to_categorical(data[[target_col]], num_classes = 7)
y_raw_factor <- as.factor(data[[target_col]])

# 3. Stratified Split Data ----------------------------------------------
set.seed(42)
test_idx <- createDataPartition(y_raw_factor, p = 0.15, list = FALSE)
x_test_raw <- x_all[test_idx, ]
y_test     <- y_all[test_idx, ]

x_remain <- x_all[-test_idx, ]
y_remain <- y_all[-test_idx, ]
y_remain_factor <- y_raw_factor[-test_idx]

val_p <- 0.15 / 0.85 
val_idx <- createDataPartition(y_remain_factor, p = val_p, list = FALSE)
x_val_raw   <- x_remain[val_idx, ]
y_val       <- y_remain[val_idx, ]

x_train_raw <- x_remain[-val_idx, ]
y_train     <- y_remain[-val_idx, ]

# --- 3.5 Calculate Class Weights ---
# We calculate these based on the TRAINING set only to avoid data leakage
train_counts <- table(y_remain_factor[-val_idx])
total_train <- sum(train_counts)
n_classes <- 7

# Inverse Frequency Formula: Total / (n_classes * class_count)
class_weights_list <- list()
for (i in 0:(n_classes - 1)) {
  class_label <- as.character(i)
  weight <- total_train / (n_classes * train_counts[class_label])
  class_weights_list[[class_label]] <- as.numeric(weight)
}

# OPTIONAL: Manual Override (Uncomment if you want to force specific severity)
class_weights_list[["0"]] <- 1.0 
class_weights_list[["1"]] <- 1.0 
class_weights_list[["2"]] <- 5.0 
class_weights_list[["3"]] <- 10.0
class_weights_list[["4"]] <- 20.0 
class_weights_list[["5"]] <- 50.0 
class_weights_list[["6"]] <- 50.0

cat("Calculated Class Weights:\n")
print(unlist(class_weights_list))

# 4. Preprocessing (Robust Scaling) --------------------------------------
all_cols <- colnames(x_train_raw)
binary_cols <- all_cols[apply(x_train_raw, 2, function(x) all(x %in% c(0, 1)))]
continuous_cols <- setdiff(all_cols, binary_cols)

scaler <- preProcess(x_train_raw[, continuous_cols], method = c("zv", "center", "scale"))

x_train <- x_train_raw
x_val   <- x_val_raw
x_test  <- x_test_raw

x_train[, continuous_cols] <- predict(scaler, x_train_raw[, continuous_cols])
x_val[, continuous_cols]   <- predict(scaler, x_val_raw[, continuous_cols])
x_test[, continuous_cols]  <- predict(scaler, x_test_raw[, continuous_cols])

# 5. Define Model --------------------------------------------------------
model <- keras_model_sequential() %>%
  layer_dense(units = FLAGS$units1, activation = "relu", input_shape = c(ncol(x_train))) %>%
  layer_dropout(rate = FLAGS$dropout1) %>%
  layer_dense(units = FLAGS$units2, activation = "relu") %>%
  layer_dropout(rate = FLAGS$dropout2)

if (FLAGS$units3 > 0) {
  model <- model %>%
    layer_dense(units = FLAGS$units3, activation = 'relu') %>%
    layer_dropout(rate = FLAGS$dropout3) 
}

model <- model %>% layer_dense(units = 7, activation = 'softmax')

# 6. Compile & Train -----------------------------------------------------
model %>% compile(
  loss = 'categorical_crossentropy',
  optimizer = optimizer_adamw(learning_rate = FLAGS$learning_rate, weight_decay = FLAGS$weight_decay),
  metrics = c('accuracy')
)

# --- DIAGNOSTIC CALLBACK ---
callback_weightnorm_f1 <- callback_lambda(
  on_epoch_end = function(epoch, logs) {
    if (epoch %% 50 == 0) {
      weight_norm <- tryCatch({
        sum(sapply(model$trainable_weights, function(w) as.numeric(tf$norm(w))))
      }, error = function(e) -1)
      
      val_probs <- model %>% predict(x_val, verbose = 0)
      val_preds <- apply(val_probs, 1, which.max) - 1
      val_true  <- apply(y_val, 1, which.max) - 1
      
      cm <- confusionMatrix(factor(val_preds, levels = 0:6), factor(val_true, levels = 0:6), mode = "everything")
      macro_f1 <- mean(cm$byClass[, "F1"], na.rm = TRUE)
      bal_acc  <- mean(cm$byClass[, "Balanced Accuracy"], na.rm = TRUE)
      
      cat(sprintf("\nEPOCH %d: Norm: %.2f | Macro F1: %.4f | Bal Acc: %.4f\n", epoch + 1, weight_norm, macro_f1, bal_acc))
      flush.console()
    }
  }
)

history <- model %>% fit(
  x_train, y_train,
  epochs = FLAGS$epochs, # Use the flag instead of hardcoded 5000          
  batch_size = FLAGS$batch_size,        
  validation_data = list(x_val, y_val),
  class_weight = class_weights_list, # <--- INTEGRATED CLASS WEIGHTS
  callbacks = list(callback_weightnorm_f1)
)

# 7. Metrics Calculation -------------------------------------------------
val_probs <- model %>% predict(x_val, verbose = 0)
val_preds <- apply(val_probs, 1, which.max) - 1
val_true  <- apply(y_val, 1, which.max) - 1
cm <- confusionMatrix(factor(val_preds, levels = 0:6), factor(val_true, levels = 0:6), mode = "everything")

macro_f1 <- mean(cm$byClass[, "F1"], na.rm = TRUE)
bal_acc  <- mean(cm$byClass[, "Balanced Accuracy"], na.rm = TRUE)

# 8. Final Report --------------------------------------------------------
# (Same as your script, but uses macro_f1 as the primary driver)
list(
  val_loss = history$metrics$val_loss[length(history$metrics$val_loss)],
  val_accuracy = history$metrics$val_accuracy[length(history$metrics$val_accuracy)],
  val_f1 = macro_f1,
  val_bal_acc = bal_acc
)

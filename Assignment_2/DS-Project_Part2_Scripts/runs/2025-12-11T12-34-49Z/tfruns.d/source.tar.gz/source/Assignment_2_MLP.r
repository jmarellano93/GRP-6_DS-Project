# ==============================================================================
# 0. Environment Setup (Keras 3 + PyTorch Backend)
# ==============================================================================
# 1. Restart R before running this!

library(reticulate)

# 2. Point to your Keras 3 + Torch environment
use_python("/Users/Jujou/miniforge3/envs/keras3_torch/bin/python", required = TRUE)

# 3. Force Backend (Double-Check)
Sys.setenv(KERAS_BACKEND = "torch")

# 4. Load Libraries (NO tfruns here)
library(keras3) 
library(caret)
library(dplyr)

# 5. Helper for "Default value if null"
`%||%` <- function(x, y) if (is.null(x)) y else x

# ==============================================================================
# 1. Hyperparameter Definitions (Standard R List, NOT tfruns)
# ==============================================================================
FLAGS <- list(
  dropout1 = 0,
  dropout2 = 0,
  dropout3 = 0.0, 
  units1 = 128,
  units2 = 256,
  units3 = 0,    
  learning_rate = 0.001,
  batch_size = 128,
  epochs = 100
)

# ==============================================================================
# 2. Load & Prepare Data
# ==============================================================================
data <- read.csv("/Users/Jujou/Documents/Repos/GRP-6_DS-Project/DS-Project_data/Intermediate/Assignment_2_cleaned.csv")
target_col <- "target_class"

x_all <- data %>% select(-all_of(target_col)) %>% as.matrix()

# FIX: Keras 3 / PyTorch requires Integers (0-7)
raw_labels <- as.integer(data[[target_col]]) - 1

# Keras 3 standard utility
y_all <- to_categorical(raw_labels, num_classes = 8)

# ==============================================================================
# 3. Split Data
# ==============================================================================
set.seed(42)
n_rows  <- nrow(x_all)
test_idx <- sample(1:n_rows, size = floor(0.15 * n_rows))

x_test_holdout_raw <- x_all[test_idx, ]
y_test_holdout     <- y_all[test_idx, ]
x_cv_raw <- x_all[-test_idx, ]
y_cv     <- y_all[-test_idx, ]

# ==============================================================================
# 4. Cross-Validation Loop
# ==============================================================================
k <- 5
folds <- cut(seq(1, nrow(x_cv_raw)), breaks = k, labels = FALSE)

results <- data.frame(
  Fold = integer(k),
  Train_Loss = numeric(k), Val_Loss = numeric(k),
  Train_Acc = numeric(k), Val_Acc = numeric(k)
)

cat("Starting", k, "-Fold Cross-Validation on M3 GPU (PyTorch)...\n")

for (i in seq_len(k)) {
  cat("\n--- Processing Fold #", i, "---\n")
  
  # a. Split
  val_indices      <- which(folds == i, arr.ind = TRUE)
  x_fold_val_raw   <- x_cv_raw[val_indices, , drop = FALSE]
  y_fold_val       <- y_cv[val_indices, , drop = FALSE]
  x_fold_train_raw <- x_cv_raw[-val_indices, , drop = FALSE]
  y_fold_train     <- y_cv[-val_indices, , drop = FALSE]
  
  # b. Scale
  fold_scaler <- preProcess(x_fold_train_raw, method = c("zv", "center", "scale"))
  x_fold_train <- predict(fold_scaler, x_fold_train_raw)
  x_fold_val   <- predict(fold_scaler, x_fold_val_raw)
  
  # c. Define Model (Corrected for Keras 3)
  # NOTE: input_shape goes inside keras_model_sequential()
  model <- keras_model_sequential(input_shape = c(ncol(x_fold_train))) %>%
    layer_dense(units = FLAGS$units1, activation = "relu") %>%
    layer_dropout(rate = FLAGS$dropout1) %>%
    layer_dense(units = FLAGS$units2, activation = "relu") %>%
    layer_dropout(rate = FLAGS$dropout2)
  
  if (FLAGS$units3 > 0) {
    model <- model %>%
      layer_dense(units = FLAGS$units3, activation = "relu") %>%
      layer_dropout(rate = FLAGS$dropout3)
  }
  
  model <- model %>% layer_dense(units = 8, activation = "softmax")
  
  # d. Compile
  model %>% compile(
    loss = "categorical_crossentropy",
    optimizer = optimizer_adam(learning_rate = FLAGS$learning_rate),
    metrics = c("accuracy")
  )
  
  # e. Train
  history <- model %>% fit(
    x = x_fold_train, y = y_fold_train,
    batch_size = FLAGS$batch_size,
    epochs = FLAGS$epochs,
    verbose = 0,
    validation_data = list(x_fold_val, y_fold_val)
  )
  
  # f. Extract Metrics
  val_acc_vec   <- history$metrics$val_accuracy %||% history$metrics$val_acc
  train_acc_vec <- history$metrics$accuracy     %||% history$metrics$acc
  val_loss_vec  <- history$metrics$val_loss
  train_loss_vec <- history$metrics$loss
  
  best_idx <- which.max(val_acc_vec)
  
  results[i, ] <- c(i, train_loss_vec[best_idx], val_loss_vec[best_idx], 
                    train_acc_vec[best_idx], val_acc_vec[best_idx])
  
  cat(sprintf("Fold %d | Max Val Acc: %.4f (Epoch %d)\n", i, val_acc_vec[best_idx], best_idx))
  
  # Clear GPU memory
  keras3::k_clear_session()
}

# ==============================================================================
# 5. Report
# ==============================================================================
cat("\n========================================\n")
avg_train_acc <- mean(results$Train_Acc)
avg_val_acc   <- mean(results$Val_Acc)
gap           <- avg_train_acc - avg_val_acc

cat("Avg Train Accuracy: ", round(avg_train_acc, 4), "\n")
cat("Avg Val Accuracy:   ", round(avg_val_acc, 4), "\n")
cat("Overfitting Gap:    ", round(gap, 4), "\n")
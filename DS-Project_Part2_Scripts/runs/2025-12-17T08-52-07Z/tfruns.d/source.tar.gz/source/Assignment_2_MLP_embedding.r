library(keras3)
library(caret)
library(dplyr)
library(tfruns)
library(tensorflow)

# 1. Hyperparameter flags ------------------------------------------------
FLAGS <- flags(
  # --- Architecture ---
  flag_integer("units1", 512),
  flag_integer("units2", 256),
  flag_integer("units3", 0),
  flag_integer("emb_size", 4),      # Size of the occupation embedding vector
  
  # --- Regularization ---
  flag_numeric("dropout1", 0.0),
  flag_numeric("dropout2", 0.0),
  flag_numeric("dropout3", 0.0),
  flag_numeric("weight_decay", 0.01),
  
  # --- Optimization ---
  flag_numeric("learning_rate", 0.001),
  flag_integer("batch_size", 256),
  flag_integer("epochs", 100)
)

# 2. Load Data -----------------------------------------------------------
data <- read.csv("/Users/Jujou/Documents/Repos/GRP-6_DS-Project/DS-Project_data/Intermediate/Assignment_2_cleaned_v3.csv")
target_col <- "target_class"
cat_col <- "OCCUPATION_TYPE_INT" # Ensure this matches your preprocessed name

# 3. Stratified Split Data -----------------------------------------------
set.seed(42)
y_raw_factor <- as.factor(data[[target_col]])
train_idx <- createDataPartition(y_raw_factor, p = 0.70, list = FALSE)

# Initial Split
train_data <- data[train_idx, ]
temp_data  <- data[-train_idx, ]

# Split remaining 30% into Val (15%) and Test (15%)
val_idx <- createDataPartition(temp_data[[target_col]], p = 0.5, list = FALSE)
val_data  <- temp_data[val_idx, ]
test_data <- temp_data[-val_idx, ]

# 4. Separate & Preprocess Inputs (FIXED) ----------------------------------------

# Define which columns are numeric/boolean
num_cols <- setdiff(names(train_data), c(target_col, cat_col))

# Create the scaler based on training data only
scaler <- preProcess(train_data[, num_cols], method = c("zv", "center", "scale"))

prepare_inputs <- function(df) {
  # 1. Scale numeric features and convert to numeric matrix
  # This prevents "object" types from character leftovers
  x_num_mat <- as.matrix(predict(scaler, df[, num_cols]))
  storage.mode(x_num_mat) <- "double" 
  
  # 2. Extract categorical integer and ensure it is a numeric matrix
  # Subtracting 1 if you haven't already to ensure 0-indexing for Embeddings
  x_cat_mat <- as.matrix(as.numeric(df[[cat_col]]))
  storage.mode(x_cat_mat) <- "double"
  
  return(list(x_num_mat, x_cat_mat))
}

# Apply the fixed function
x_train <- prepare_inputs(train_data)
x_val   <- prepare_inputs(val_data)

# Ensure targets are also strictly numeric
y_train <- to_categorical(as.numeric(train_data[[target_col]]), num_classes = 7)
y_val   <- to_categorical(as.numeric(val_data[[target_col]]), num_classes = 7)

# 5. Define Functional Model ---------------------------------------------

# Input A: Numeric/Boolean
input_num <- layer_input(shape = ncol(x_train[[1]]), name = "numeric_input")

# Input B: Occupation (Embeddings)
input_cat <- layer_input(shape = 1, name = "categorical_input")

emb_layer <- input_cat %>% 
  layer_embedding(input_dim = 18, output_dim = FLAGS$emb_size) %>% 
  layer_flatten()

# Merge branches
merged <- layer_concatenate(list(input_num, emb_layer))

# Hidden Layers
main_path <- merged %>%
  layer_dense(units = FLAGS$units1, activation = "relu") %>%
  layer_dropout(rate = FLAGS$dropout1) %>%
  layer_dense(units = FLAGS$units2, activation = "relu") %>%
  layer_dropout(rate = FLAGS$dropout2)

if (FLAGS$units3 > 0) {
  main_path <- main_path %>%
    layer_dense(units = FLAGS$units3, activation = "relu") %>%
    layer_dropout(rate = FLAGS$dropout3)
}

# Output
output <- main_path %>% layer_dense(units = 7, activation = "softmax")

model <- keras_model(inputs = list(input_num, input_cat), outputs = output)

# 6. Compile & Train -----------------------------------------------------
model %>% compile(
  loss = 'categorical_crossentropy',
  optimizer = tensorflow::tf$keras$optimizers$AdamW(
    learning_rate = FLAGS$learning_rate, 
    weight_decay = FLAGS$weight_decay
  ),
  metrics = c('accuracy')
)

history <- model %>% fit(
  x = x_train, y = y_train,
  epochs = FLAGS$epochs,
  batch_size = FLAGS$batch_size,
  validation_data = list(x_val, y_val),
  verbose = 2
)

# 7. Evaluation ----------------------------------------------------------
val_probs <- model %>% predict(x_val, verbose = 0)
val_preds <- apply(val_probs, 1, which.max) - 1
val_true  <- apply(y_val, 1, which.max) - 1

cm <- confusionMatrix(
  factor(val_preds, levels = 0:6),
  factor(val_true, levels = 0:6),
  mode = "everything"
)

macro_f1 <- mean(cm$byClass[, "F1"], na.rm = TRUE)
bal_acc  <- mean(cm$byClass[, "Balanced Accuracy"], na.rm = TRUE)

# 8. Return to tfruns ----------------------------------------------------
list(
  val_loss = history$metrics$val_loss[which.max(history$metrics$val_accuracy)],
  val_accuracy = max(history$metrics$val_accuracy),
  val_f1 = macro_f1,
  val_bal_acc = bal_acc
)
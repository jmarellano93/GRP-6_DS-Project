library(keras3)
library(caret)
library(dplyr)
library(tfruns)
library(tensorflow)

# 1. Hyperparameter flags ------------------------------------------------
FLAGS <- flags(
  flag_integer("units1", 128),
  flag_integer("units2", 64),
  flag_integer("units3", 0),
  
  flag_numeric("dropout1", 0.0),
  flag_numeric("dropout2", 0.0),
  flag_numeric("dropout3", 0.0),
  
  flag_numeric("learning_rate", 0.005),
  flag_numeric("momentum", 0.9),
  flag_numeric("l2", 1e-4),
  
  flag_integer("batch_size", 64),
  flag_integer("epochs", 5000)
)

# 2. Load Data -----------------------------------------------------------
data <- read.csv(
  "/Users/Jujou/Documents/Repos/GRP-6_DS-Project/DS-Project_data/Intermediate/Assignment_2_cleaned_v2.csv",
  stringsAsFactors = FALSE
)

target_col <- "target_class"

# 3. Stratified Split Data (Original Distribution) -----------------------
set.seed(42)
y_factor <- factor(data[[target_col]])

# --- Test set (15%) ---
test_idx <- createDataPartition(y_factor, p = 0.15, list = FALSE)
test_data <- data[test_idx, ]
remain_data <- data[-test_idx, ]

# --- Validation set (15% total) ---
val_p <- 0.15 / 0.85
val_idx <- createDataPartition(
  factor(remain_data[[target_col]]),
  p = val_p,
  list = FALSE
)

val_data   <- remain_data[val_idx, ]
train_data <- remain_data[-val_idx, ]

cat("Training distribution (original):\n")
print(table(train_data[[target_col]]))

# 4. Convert to numeric matrices ----------------------------------------
x_train_raw <- train_data %>%
  select(-all_of(target_col)) %>%
  mutate(across(everything(), as.numeric)) %>%
  as.matrix()

x_val_raw <- val_data %>%
  select(-all_of(target_col)) %>%
  mutate(across(everything(), as.numeric)) %>%
  as.matrix()

x_test_raw <- test_data %>%
  select(-all_of(target_col)) %>%
  mutate(across(everything(), as.numeric)) %>%
  as.matrix()

storage.mode(x_train_raw) <- "double"
storage.mode(x_val_raw)   <- "double"
storage.mode(x_test_raw)  <- "double"

y_train <- to_categorical(train_data[[target_col]], num_classes = 7)
y_val   <- to_categorical(val_data[[target_col]],   num_classes = 7)
y_test  <- to_categorical(test_data[[target_col]],  num_classes = 7)

# 5. Preprocessing (z-score scaling for continuous features) ------------
continuous_cols <- colnames(x_train_raw)[
  apply(x_train_raw, 2, function(x) !all(x %in% c(0, 1)))
]

scaler <- preProcess(
  x_train_raw[, continuous_cols, drop = FALSE],
  method = c("zv", "center", "scale")
)

x_train <- x_train_raw
x_val   <- x_val_raw
x_test  <- x_test_raw

x_train[, continuous_cols] <- predict(
  scaler, x_train_raw[, continuous_cols, drop = FALSE]
)
x_val[, continuous_cols] <- predict(
  scaler, x_val_raw[, continuous_cols, drop = FALSE]
)
x_test[, continuous_cols] <- predict(
  scaler, x_test_raw[, continuous_cols, drop = FALSE]
)

# 6. Define Model --------------------------------------------------------
reg <- regularizer_l2(FLAGS$l2)

model <- keras_model_sequential() %>%
  layer_input(shape = ncol(x_train)) %>%
  layer_dense(
    units = FLAGS$units1,
    activation = "relu",
    kernel_regularizer = reg
  ) %>%
  layer_dense(
    units = FLAGS$units2,
    activation = "relu",
    kernel_regularizer = reg
  )

if (FLAGS$units3 > 0) {
  model <- model %>%
    layer_dense(
      units = FLAGS$units3,
      activation = "relu",
      kernel_regularizer = reg
    )
}

model <- model %>%
  layer_dense(units = 7, activation = "softmax")

# 7. Compile -------------------------------------------------------------
model %>% compile(
  loss = "categorical_crossentropy",
  optimizer = optimizer_sgd(
    learning_rate = FLAGS$learning_rate,
    momentum = FLAGS$momentum
  ),
  metrics = list(
    "accuracy",
    metric_top_k_categorical_accuracy(k = 2),
    metric_categorical_crossentropy()
  )
)

# 8. Train ---------------------------------------------------------------
history <- model %>% fit(
  x_train, y_train,
  epochs = FLAGS$epochs,
  batch_size = FLAGS$batch_size,
  validation_data = list(x_val, y_val),
  callbacks = list(
    callback_early_stopping(
      monitor = "val_accuracy",
      patience = 30,
      restore_best_weights = TRUE
    )
  )
)

# 9. Final Validation Metrics --------------------------------------------
val_probs <- model %>% predict(x_val, verbose = 0)
val_preds <- apply(val_probs, 1, which.max) - 1
val_true  <- apply(y_val, 1, which.max) - 1

cm <- confusionMatrix(
  factor(val_preds, levels = 0:6),
  factor(val_true,  levels = 0:6),
  mode = "everything"
)

list(
  val_accuracy = cm$overall["Accuracy"],
  val_f1       = mean(cm$byClass[, "F1"], na.rm = TRUE),
  val_bal_acc  = mean(cm$byClass[, "Balanced Accuracy"], na.rm = TRUE)
)
